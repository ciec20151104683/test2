/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50556
Source Host           : localhost:3306
Source Database       : student

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2018-07-05 17:07:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `s_id` int(15) NOT NULL,
  `s_pwd` char(100) DEFAULT NULL,
  `s_no` char(50) DEFAULT NULL,
  `s_name` char(100) DEFAULT NULL,
  `s_age` int(5) DEFAULT NULL,
  `s_sex` char(20) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '123', '2015110', 'wang', '22', '女');
INSERT INTO `student` VALUES ('2', '123', '2015111', 'zhang', '20', '男');
