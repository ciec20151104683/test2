package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.entity.User;
import com.qst.servlet.user;

public class TeacherServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		UserDao ud = new UserDaoImpl();
		
		
		user user = new user(); //实例化一个对象，组装属性
		 //实例化一个对象，组装属性
		
		
	
		
		HttpSession session = request.getSession();


		String s= request.getSession().getAttribute("user").toString();
		System.out.println(s);
		user.setName(s);
		
		List<user> userAll = ud.getTeacherAll(s);
		
		request.setAttribute("userAll", userAll);
		request.getRequestDispatcher("info.jsp").forward(request, response);
	System.err.println(request);
	}
}
