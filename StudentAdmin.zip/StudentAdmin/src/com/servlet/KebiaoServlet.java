package com.servlet;

import java.io.IOException;
import java.util.function.ToIntFunction;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.entity.User;
import com.qst.bean.ke;

/**
 * Servlet implementation class JkServlet
 */
@WebServlet("/KebiaoServlet")
public class KebiaoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public KebiaoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8"); // 将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		
		String k_time = request.getParameter("k_time");
     	String day1 = request.getParameter("day1");
		String day2 = request.getParameter("day2");
		String day3 = request.getParameter("day3");
		String day4 = request.getParameter("day4");
		String day5 = request.getParameter("day5");
		String day6 = request.getParameter("day6");
		String day7 = request.getParameter("day7");
		String name = request.getParameter("str");
		System.out.println(name);
		ke ke = new ke(); // 实例化一个对象，组装属性
		
	
		

	

	
		
		UserDao ud = new UserDaoImpl();

		if (ud.kebiao(k_time, day1, day2, day3, day4, day5, day6, day7,name)) {
			
			request.getRequestDispatcher("/Skall").forward(request, response);

		}else {
			response.sendRedirect("guanli.jsp");
		}
		// 获取jsp页面传过来的参数


	}

}
