package com.dao;

import java.util.List;

import com.entity.User;
import com.qst.bean.ke;
import com.qst.servlet.*;

public interface UserDao {
	
	public boolean login(String name,String pwd);//登录
	public boolean register(User user);//注册
	public boolean Hang(ke ke);//注册
	public boolean chengji(String name,String  mark);
	public List<User> getUserAll();//返回学生信息集合
	public List<user> getTeacherAll(String str);//返回老师信息集合
	public boolean delete(int id) ;//根据id删除用户
	public boolean update(int id,String name, String password,String email,String mark) ;//更新用户信息
	public List<user> getTeacherAll1();
	public boolean jiake(String k_time, String day1, String day2, String day3, String day4, String day5, String day6, String day7,String name,String s);
	public List<ke> getKeAll();
	public List<ke> getKeAll1(String b);
	public boolean kebiao(String k_time, String day1, String day2, String day3, String day4, String day5, String day6, String day7,String name);

}
