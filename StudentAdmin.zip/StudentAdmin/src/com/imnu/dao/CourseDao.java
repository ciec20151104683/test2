package com.imnu.dao;

import java.util.List;



public class CourseDao {
	//public boolean login(String name,String pwd);//登录
	//public boolean register(User user);//注册
	//public List<CourseBean> getUserAll();//返回用户信息集合
	//public boolean delete(int c_id) ;//根据id删除用户
	//public boolean update(String c_id,String c_name, String c_time,String c_add, String t_id,String t_name) ;//更新用户信息
}
