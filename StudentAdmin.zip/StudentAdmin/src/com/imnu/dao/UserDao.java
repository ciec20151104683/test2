package com.imnu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.imnu.bean.ke;
import com.imnu.bean.user;
import com.imnu.util.DBconn;



public class UserDao {

	public boolean login(String name, String pwd) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			    DBconn.init();
				ResultSet rs = DBconn.selectSql("select * from user where name='"+name+"' and pwd='"+pwd+"'");
				while(rs.next()){
					if(rs.getString("name").equals(name) && rs.getString("pwd").equals(pwd)){
						flag = true;
					}
				}
				DBconn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public List<user> getTeacherAll1() {
		// TODO Auto-generated method stub
		List<user> list = new ArrayList<user>();

		try {
			DBconn.init();
			
			ResultSet rs = DBconn.selectSql("select * from teacher where name=" +"'" +"'");
			System.out.println(rs);
			while (rs.next()) {

				user user = new user();
				user.setId(rs.getInt("id"));

				user.setName(rs.getString("name"));
				user.setPwd(rs.getString("password"));
				user.setEmail(rs.getString("email"));


				list.add(user);
			}
			DBconn.closeConn();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<ke> getKeAll() {
		// TODO Auto-generated method stub
		List<ke> list = new ArrayList<ke>();

		try {
			DBconn.init();
			ResultSet rs = DBconn.selectSql("select * from kebiao");
			while (rs.next()) {
				ke ke = new ke();
				ke.setK_time(rs.getString("k_time"));
				ke.setDay1(rs.getString("day1"));
				ke.setDay2(rs.getString("day2"));
				ke.setDay3(rs.getString("day3"));
				ke.setDay4(rs.getString("day4"));
				ke.setDay5(rs.getString("day5"));
				ke.setDay6(rs.getString("day6"));
				ke.setDay7(rs.getString("day7"));
				ke.setName(rs.getString("name"));
				ke.setS(rs.getString("s"));
				
				list.add(ke);
			}
			DBconn.closeConn();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean Hang(ke ke) {
		// TODO Auto-generated method stub
		boolean flag = false;
		DBconn.init();
		int i = DBconn.addUpdDel("insert into kebiao(k_time) " + "values('" + ke.getK_time() + "')");
		if (i > 0) {
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}

	public boolean update(int id, String name, String password, String email, String mark) {
		// TODO Auto-generated method stub
		boolean flag = false;
		DBconn.init();
		String sql = "update user set name ='" + name + "' , password ='" + password + "' , email = '" + email
				+ "' , chengji= '" + mark + "'  where id = " + id;
		int i = DBconn.addUpdDel(sql);
		if (i > 0) {
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}

	public boolean jiake(String k_time, String day1, String day2, String day3, String day4, String day5, String day6,
			String day7, String name, String s) {
		// TODO Auto-generated method stub
		boolean flag = false;
		DBconn.init();
		String sql = "update kebiao set day1 ='" + day1 + 
				"' , day2 ='" + day2 +
				"' , day3 = '" + day3 +
				"' , day4= '" + day4 + 
				"' , day5= '" + day5+ 
				"' , day6= '" + day6+ 
				"' , day7= '" + day7 + 
				"' , name= '" + name + 
				"' , k_time= '" + k_time + 
				"'  where s="+s;
		int i = DBconn.addUpdDel(sql);
		if (i > 0) {
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}

}
