package com.imnu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.imnu.util.DBconn;



public class UserDao {

	public boolean login(String name, String pwd) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			    DBconn.init();
				ResultSet rs = DBconn.selectSql("select * from user where name='"+name+"' and pwd='"+pwd+"'");
				while(rs.next()){
					if(rs.getString("name").equals(name) && rs.getString("pwd").equals(pwd)){
						flag = true;
					}
				}
				DBconn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

}
