package com.imnu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.imnu.bean.CourseBean;
import com.imnu.util.DBconn;



public class CourseDaoImply {
/*public boolean register(User user) {
		
		boolean flag = false;
		DBconn.init();
		int i =DBconn.addUpdDel("insert into user(name,worknumber,sex,home,gangwei,info) " +
				"values('"+user.getName()+"','"+user.getWorknumber()+"','"+user.getSex()+"','"+user.getHome()+"','"+user.getGangwei()+"','"+user.getInfo()+"')");
		if(i>0){
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}
    public boolean login(String name, String pwd) {
		boolean flag = false;
		try {
			    DBconn.init();
				ResultSet rs = DBconn.selectSql("select * from user where name='"+name+"' and pwd='"+pwd+"'");
				while(rs.next()){
					if(rs.getString("name").equals(name) && rs.getString("pwd").equals(pwd)){
						flag = true;
					}
				}
				DBconn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}*/
	public List<CourseBean> getCourseAll() {
		List<CourseBean> list = new ArrayList<CourseBean>();
    	try {
		    DBconn.init();
			ResultSet rs = DBconn.selectSql("select * from course");
			while(rs.next()){
				CourseBean courseBean = new CourseBean();
				courseBean.setC_id(rs.getString("c_id"));
				courseBean.setC_name(rs.getString("c_name"));
				courseBean.setC_time(rs.getString("C_time"));
				courseBean.setC_add(rs.getString("C_add"));
				courseBean.setT_id(rs.getInt("home"));
				//System.out.println(rs.getString("home"));
				courseBean.setT_name(rs.getString("T_name"));
				
				list.add(courseBean);
			}
			DBconn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	/*public boolean update(int id,String name, String worknumber,String sex, String home,String gangwei,String info) {
		boolean flag = false;
		DBconn.init();
		String sql ="update user set name ='"+name
				+"' , worknumber ='"+worknumber
				+"' , sex ='"+sex
				+"' , home ='"+home
				+"' , gangwei ='"+gangwei
				+"' , info ='"+info+"' where id = "+id;
		int i =DBconn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}
	public boolean delete(int id) {
		boolean flag = false;
		DBconn.init();
		String sql = "delete  from user where id="+id;
		int i =DBconn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBconn.closeConn();
		return flag;
	}
	public boolean update1(int id, String name, String worknumber, String sex, String home,String gangwei, String info) {
		// TODO Auto-generated method stub
		return false;
	}
    */
}
