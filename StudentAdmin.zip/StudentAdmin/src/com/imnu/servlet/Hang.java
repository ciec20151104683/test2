package com.imnu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.imnu.bean.ke;
import com.imnu.dao.UserDao;



/**
 * Servlet implementation class Hang
 */
@WebServlet("/Hang")
public class Hang extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Hang() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8"); //将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		String hang = request.getParameter("hang"); //获取jsp页面传过来的参数
		ke ke = new ke(); //实例化一个对象，组装属性
		ke.setK_time(hang);
		UserDao ud = new UserDao();
		if(ud.Hang(ke)){
				//向request域中放置参数
				response.sendRedirect("jiake.jsp");

			}
		}
		
	
	

}
