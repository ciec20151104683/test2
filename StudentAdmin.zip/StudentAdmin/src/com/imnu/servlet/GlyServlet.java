package com.imnu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.imnu.bean.user;
import com.imnu.dao.UserDao;


public class GlyServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //将编码改为utf-8
		response.setContentType("text/html;charset=UTF-8");
		UserDao ud = new UserDao();
		
		String str = request.getParameter("str");
		user user = new user(); //实例化一个对象，组装属性
		user.setSavename(str);
		List<user> userAll = ud.getTeacherAll1();
		request.setAttribute("userAll", userAll);
		request.getRequestDispatcher("SelectCourse.jsp").forward(request, response);
	System.err.println(request);
	}
}
