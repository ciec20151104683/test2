package com.qst.servlet;

import java.awt.print.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDao;
import com.dao.UserDaoImpl;
import com.entity.User;
import com.sun.xml.internal.bind.v2.runtime.Name;
import com.util.DBUtil;

import sun.security.util.Password;


@WebServlet("/serlet")
public class serlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public serlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("username");
		String password = request.getParameter("pwd");	
	
		Connection conn = DBUtil.getConnection();
		String sql="select * from teacher where name=? and password=?";
		//List<user> list = new ArrayList<user>();
		 
		PreparedStatement pstm =null;
		ResultSet rs = null ;
		user user = null;
		
		try {
			
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, name);
			pstm.setString(2, password);
			rs = pstm.executeQuery();
			while(rs.next()) {
				 
				user=new user();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setPwd(rs.getString("password"));
		
				//list.add(user);
			}
			//request.setAttribute("list", list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(conn,pstm,rs);
		}

	     	    		if(user!=null) {
	
	    			HttpSession session = request.getSession();
	    			session.setAttribute("user", name);
	    			request.setAttribute("sign", name);
	    			request.getRequestDispatcher("/info.jsp").forward(request, response);
	    			
	    		}else {
	    			response.sendRedirect("login.jsp");
	    		}
	        }
	       
	        
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
